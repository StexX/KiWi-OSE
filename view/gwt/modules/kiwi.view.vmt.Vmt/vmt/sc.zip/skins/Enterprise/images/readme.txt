Some of the icons used are from the FAMFAMFAM Silk Icon Collection (http://www.famfamfam.com/lab/icons/silk/)
and are licensed under Creative Commons Attribution 2.5 License.